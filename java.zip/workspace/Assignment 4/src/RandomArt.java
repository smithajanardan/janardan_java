// Student information for assignment.
// Student 1 Name: Smitha Janardan
// Student 1 UTEID: ssj398
// Student 2 Name: Zohaib Momin
// Student 2 UTEID: zpm66

// Slip days used:

// On our (my) honor Smitha Janardan and Zohaib Momin this
// assignment is our (my) own work.

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Stack;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

public class RandomArt {

    public static void main(String[] args) {
        ArtFrame f = new ArtFrame();
        f.start();
    }
} // end of RandomArt class

class ArtFrame extends JFrame {
    
	private static final long serialVersionUID = 1L;
	private ArtPanel thePanel;
    private JLabel theCurrentExpression;

    public ArtFrame(){
        setTitle("Assignment 4 - Random Art");
        setLocation(100,100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // add the menu for Colored Art options
        setJMenuBar(createMenu());

        // create panel with buttons
        thePanel = new ArtPanel();
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(getButton("New Gray", true));
        buttonPanel.add(getButton("New Color", false));

        // create the label with the current random expression
        theCurrentExpression = new JLabel(thePanel.getExpressionAsString());
        theCurrentExpression.setFont(new Font("Serif", Font.PLAIN, 16));


        // add components to frame
        add(thePanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        add(theCurrentExpression, BorderLayout.NORTH);
        pack();
        
    }

    // create menu options for which method is used
    // to create colored random art. Students must implement
    // at least two different ways of generating a random
    // art image with color.
    private JMenuBar createMenu() {
        final int NUM_OPTIONS = ArtPanel.NUM_COLOR_OPTIONS;
        JMenuBar menu = new JMenuBar();
        final String label = "Color Option";
        JMenu colorOptions = new JMenu(label);
        menu.add(colorOptions);
        // add the options. Must connect listeners for when these
        // options are selected. When activated the menu option
        // will update the panel with the new color option.
        for(int i = 0; i < NUM_OPTIONS; i++) {
            JMenuItem temp = colorOptions.add(label + " " + (i + 1));
            temp.addActionListener(createMenuListener(i+1));
         }
        return menu;
    }

    // create action listeners for the menu buttons
    public ActionListener createMenuListener(final int i) {
        return new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	// set indicator to choosen color option and repaint
            	ArtPanel.i = i;
        		colorAction();
            }
        };
    }

	public JButton getButton(String label, final boolean makeColor){
        JButton result = new JButton(label);
        result.addActionListener(
        		createButtonListener(makeColor));
        return result;
    }
    
	// create action listeners for bottom buttons
    public ActionListener createButtonListener(final boolean makeColor) {
        return new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	// change indicators to show which button was pressed,
            	// repaint, and display the new equation
            	if (makeColor == true) {
            		ArtPanel.indicator = true;
            		ArtPanel.exp = new RandomExpression();
            		theCurrentExpression.setText(thePanel.getExpressionAsString());
            		thePanel.repaint();
            	}
            	else {
            		colorAction();
            	}
            }
        };
    }

    // repaint method for both color options
    public void colorAction() {
    	ArtPanel.indicator = false;
		ArtPanel.exp = new RandomExpression();
		if (ArtPanel.i == 1) {
			ArtPanel.expg = new RandomExpression();
			ArtPanel.expb = new RandomExpression();
		}
		theCurrentExpression.setText(thePanel.getExpressionAsString());
		thePanel.repaint();
    }
    
    public void start(){
        setVisible(true);
    }
} // end of ArtFrame class

class ArtPanel extends JPanel   {
	
    private static final long serialVersionUID = 1L;
	public static final int SIZE = 400;
    public static final int NUM_COLOR_OPTIONS = 2;
    public static RandomExpression exp;
    public static RandomExpression expg;
    public static RandomExpression expb;
    public static int i = 1; // set initial color option to 1
    public static boolean indicator = true; //set initial color to grey
    
    public ArtPanel(){ 
        setPreferredSize(new Dimension(SIZE, SIZE));
        
        // default expression
        exp = new RandomExpression("xxACSSxCAyCyxASASCAyCCAyyyAAxMSxCxCAxSySMMCMCSMSCS");
    }

	public String getExpressionAsString() {
		String result = "";
        if (indicator == true) {
        	result =  "Gray Scale Equation: " + exp.toString();
        }
        else {
        	if (i == 1) {
        		result =  "<HTML>Red Scale Equation: " + exp.toString() + "<br>Green Scale Equation: " + 
        				expg.toString() + "<br>Blue Scale Equation: " + expb.toString() + "</HTML>";
        	}
        	else if (i == 2) {
        		result =  "Color Option 2 Scale Equation: " + exp.toString();
        	}
        }
        return result;
    }

	// paints the random expression pattern
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;
        double width = getWidth();
		double height = getHeight();
		drawDot(g2, width, height);
    }

    // iterates a for loop for every pixel and draws a dot there
    private void drawDot(Graphics2D g2, double width, double height) {
        for (int x=0; x<width; x++) {
    		for (int y=0; y<height; y++) {
    			double xcoord = x/(width/2)-1;
    			double ycoord = y/(height/2)-1;
    			Color color = getColor(g2, xcoord, ycoord, width, height);
                g2.setColor(color);
            	g2.drawRect(x, y, 1, 1);	
    		}
        }
	}

    // gets the color of the dot based on which buttons were pressed
	private Color getColor(Graphics2D g2, double xcoord, double ycoord,
			double width, double height) {
		Color color = null;
		if (indicator == true) 
        	color = getGreyColor(g2, xcoord, ycoord, width, height);
        else if (i == 1) 
        	color = get1Color(g2, xcoord, ycoord, width, height);
        else if (i == 2) 
        		color = get2Color(g2, xcoord, ycoord, width, height);  
		return color;
	}

	// gets a value from 0 to 255 based on the current expression
	public static int getColorValue (RandomExpression exp, double x, double y) {
    	double value = exp.getResult(x, y);
    	return  (int) ((value+1.0)*(255/2));
    }   
    
	// finds the r,g,b values when the second color option is selected
	private Color get2Color(Graphics2D g2, double x, double y, double width, double height) {
    	int scaledr = getColorValue(exp, x, y);
    	int scaledg = getColorValue(exp, y, x);
    	int scaledb = getColorValue(exp, x, -y);
    	Color color = new Color (scaledr,scaledg,scaledb);
    	return color;
	}

	// finds the r,g,b values when the first color option is selected
	private Color get1Color(Graphics2D g2, double x, double y, double width, double height) {
    	int scaledr = getColorValue(exp, x, y);
    	int scaledg = getColorValue(expg, x, y);
    	int scaledb = getColorValue(expb, x, y);
    	Color color = new Color (scaledr,scaledg,scaledb);
    	return color;
	}

	// finds the r,g,b values when the grey option is selected
	private Color getGreyColor(Graphics g2, double x, double y, double width, double height) {
    	int value = getColorValue(exp, x, y);
    	Color color = new Color (value,value,value);
    	return color;
	}

} // end of ArtPanel class

class RandomExpression {
    // Really need to implement expressions as a
    // separate class. As is, adding things is a pain.
    // classic if else structure is dead give away that
    // operators should represented as objects.
    // The multiway else if is an antipattern!
  
    private static final String OPERATORS = "SCAMT";
    
    // functions that take a single operand
    private static final String SINGLE_OPERAND_OPERATORS = "SCT";

    private static final String OPERANDS = "xy";
    
    // probability that operand will be another expression
    // instead of a primitive
    private final double PROBABILITY_DEEPER;


    // String representation of expression. Shown is postfix
    // notation to make for easier evaluation
    private final String randExpression;

    // higher number means more complex
    // lowest allowed value = 0
    private final int EXPRESSION_COMPLEXITY; 

    private static final int DEFAULT_MAX_COMPLEXITY = 10;;
    private static final double DEFAULT_PROBABILITY_USE_OPERATOR_FOR_OPERAND = 0.85;

    // create a new Random Expression
    // with probabilityDeeper = 0.8
    // and expressionComplexity = 10
    public RandomExpression(){
        this(DEFAULT_MAX_COMPLEXITY, DEFAULT_PROBABILITY_USE_OPERATOR_FOR_OPERAND);
    }

    // pre: complexity >= 0, 0 <= deeper <= 1.0
    // higher values for complexity and deeper lead to
    // more complex expressions
    public RandomExpression(int complexity, double deeper){
        EXPRESSION_COMPLEXITY = complexity;
        PROBABILITY_DEEPER = deeper;
        randExpression = createExpression(0);
    }

    // a way to create a hard coded expression
    public RandomExpression(String s){
        EXPRESSION_COMPLEXITY = -1;
        PROBABILITY_DEEPER = -1;        
        randExpression = s;
    }

    private String createExpression(int currentLevel){
        int op = (int)(Math.random() * OPERATORS.length());
        int oper1 = (int)(Math.random() * 2);
        int oper2 = (int)(Math.random() * 2);
        String result = OPERATORS.substring(op, op + 1);
        boolean deeperFirstOperand = Math.random() < PROBABILITY_DEEPER;
        boolean deeperSecondOperand = Math.random() < PROBABILITY_DEEPER;

        // single operand operators
        if(isSingleOperandOperator(result)){
            // base case, operands are simple values, x or y
            if(!deeperFirstOperand || currentLevel == EXPRESSION_COMPLEXITY) {
                result = OPERANDS.charAt(oper1) +  result;
            }
            // recursive case, operand is another expression
            else{
                result = createExpression(currentLevel + 1) +  result;
            }
        }
        else{
            // base case, operands are simple values, x or y
            if(currentLevel == EXPRESSION_COMPLEXITY || (!deeperFirstOperand && !deeperSecondOperand)){
                result = OPERANDS.charAt(oper1) + "" + OPERANDS.charAt(oper2) + result;
            }
            // first operand is simple value, second is another expression
            else if(!deeperFirstOperand){
                result = OPERANDS.charAt(oper1) +  createExpression(currentLevel + 1) + result;
            }
            // second operand is simple value, first is another expression
            else if(!deeperSecondOperand){
                result = createExpression(currentLevel + 1) + OPERANDS.charAt(oper2) + result;
            }
            // both operands are complex expressions
            else{
                result = createExpression(currentLevel + 1) + createExpression(currentLevel + 1) + result;
            }
        }
        return result;
    }

    private boolean isSingleOperandOperator(String operator) {
        return SINGLE_OPERAND_OPERATORS.contains(operator);
    }

    // called to get result of expression at a given
    // value of x and y.
    // pre: -1.0 <= x <= 1.0, -1.0 <= y <= 1.0, 
    // post: return a value between -1.0 and 1.0, inclusive
    public double getResult(double x, double y){
        Stack<Double> operands = new Stack<Double>();
        for(int i = 0; i < randExpression.length(); i++){
            char ch = randExpression.charAt(i);
            if(ch == 'x')
                operands.push(x);
            else if(ch == 'y')
                operands.push(y);
            else{
                // operator
                double op1 = operands.pop();
                if(ch == 'S')
                    operands.push(Math.sin(Math.PI * op1));
                else if(ch == 'C')
                    operands.push(Math.cos(Math.PI * op1));
                else if(ch == 'M')
                    operands.push(op1 * operands.pop());
                else if (ch == 'A')
                    operands.push(ave(op1, operands.pop()));
                else if (ch == 'T')
                	operands.push(Math.tan(op1)/Math.tan(-1));
            }
        }
        assert operands.size() == 1 : operands.size();
        double result = operands.pop();
        result = (result < -1.0) ? -1.0 : (result > 1.0) ? 1.0 : result;
        assert -1.0 <= result && result <= 1.0 : result;
        return result;
    }

	private static double ave(double x, double y){
        return (x + y) / 2.0;
    }

    public String toString(){
        return randExpression;
    }

    // from random art, test method
    public static double getValExp(double x, double y){
        return Math.sin(Math.PI * Math.sin(Math.PI * Math.sin(Math.PI * (Math.sin(Math.PI * Math.sin(Math.PI * Math.sin(Math.PI * Math.sin(Math.PI * Math.cos(Math.PI * y))))) * Math.cos(Math.PI * Math.sin(Math.PI * Math.cos(Math.PI * ave(Math.sin(Math.PI * y), (x * x)))))))));
    }

    // simple by hand test
    public static double getValueHardCoded(double x, double y){
        double pi = Math.PI;
        return Math.sin(pi * Math.cos(pi * Math.cos(pi * Math.sin(pi * ave(Math.cos(pi * y),y) * Math.sin(pi * x * y )))));
    } 
} // end of RandomExpression class