// Student information for assignment.
// Student 1 Name: Smitha Janardan
// Student 1 UTEID: ssj398
// Slip days used:
// replace <Student1> with your name
// stating this is your own work.
// On my honor Smitha Janardan this
// assignments is my own work.

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.font.FontRenderContext;
import java.awt.font.TextLayout;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.Timer;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class LilacChaserMain {
    public static void main(String[] args) { 
        LilacChaserFrame f = new LilacChaserFrame(); 
        f.start(); 
    } 
}

class LilacChaserFrame extends JFrame {
    
    private static final int TIMER_DEFAULT_DELAY = 100;
    private static final int MAX_FRAMES_PER_SECOND = 25;
    
    private LilacChaserPanel panel;
    private Timer timer;
    
    public LilacChaserFrame(){
        super("Lilac Chaser");
        setSize(500, 500);
        setLocation(100, 100);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new LilacChaserPanel();
        add(panel);
        add(new TitlePanel(), "North");
        addTimer();
        addSlider();
        
        pack();
    }
    
    // post: create and add a slider to control time delay
    // based on code from Stuart Reges at UWCS
    private void addSlider() {
        // slider to control frames per second
        final JSlider slider = new JSlider(1, MAX_FRAMES_PER_SECOND);
        slider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                timer.setDelay(1000 / slider.getValue());
            } });
        
        //  start at 10 frames per second 
        slider.setValue(10);
        
        //  create a panel for the slider and its slow/fast labels 
        JPanel p = new JPanel();
        p.setPreferredSize(new Dimension(500, 30));
        p.add(new JLabel("slow"));
        p.add(slider);
        p.add(new JLabel("fast"));
        add(p, "South");
    }
    
    // post: Timer created
    private void addTimer(){
        timer = new Timer(TIMER_DEFAULT_DELAY, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // timer has gone off, repaint panel
                panel.repaint();
            } }); 
    }
    
    // pre: all components initialized
    // post: frame set to visible
    public void start(){
        setVisible(true);
        timer.start();
    }
}

class LilacChaserPanel extends JPanel {
    
	// sizes of the panel and patches
    public static final int PREFERRED_DIMENSION = 400;
    public static final int SIZE_PANEL = 500;
    public static final int NUM_PATCHES = 12;
    public static final int NUM_CIRC_FOR_PATCH = 10;
    public static final int PATCH_SIZE = SIZE_PANEL / 10;
    
    // starting color for the patch
    public static final int START_RED = 178;
    public static final int START_GREEN = 153;
    public static final int START_BLUE = 178;
    
    // ending color of the patch
    public static final int FINAL_RED = 250;
    public static final int FINAL_GREEN = 0;
    public static final int FINAL_BLUE = 250;
    
    // how much the color of each patch should change
    public static final int RED_CHANGE = Math.abs(FINAL_RED-START_RED)/NUM_CIRC_FOR_PATCH;
    public static final int GREEN_CHANGE = Math.abs(FINAL_GREEN-START_GREEN)/NUM_CIRC_FOR_PATCH;
    public static final int BLUE_CHANGE = Math.abs(FINAL_BLUE-START_BLUE)/NUM_CIRC_FOR_PATCH;
    
    // more dimensions
    public static final double ANGLE_INC=(2*Math.PI)/NUM_PATCHES;
    public static final double DISTANCE_TO_PATCH = (3*PATCH_SIZE) + (PATCH_SIZE/3);

    // background color
    private static final Color GREY = new Color(170, 170, 170);
    
    // position of the starting patch
    public double START_ANGLE = Math.toRadians(-15);
    
    public LilacChaserPanel(){
         setPreferredSize(new Dimension(PREFERRED_DIMENSION, PREFERRED_DIMENSION));
    	 setBackground(GREY);
    }

    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
                RenderingHints.VALUE_ANTIALIAS_ON);
        
        // translate to center of panel and draw crosshairs
        g2.translate((getWidth()/2), (getHeight()/2));
        g2.setStroke(new BasicStroke(2));
        g2.setColor(Color.BLACK);
        g2.drawLine(10, 0, -10, 0);
        g2.drawLine(0, 10, 0, -10);
        
        // draw all of the patches
        drawPatches(g2);
    }
    
    // draw the a group of patches around the center
	private void drawPatches(Graphics2D g2) {
		double angle = START_ANGLE;
		for (int i = 0; i < NUM_PATCHES-1; i++) {
			angle += ANGLE_INC;
			translate(g2, angle, DISTANCE_TO_PATCH, 1);
			drawPatch(g2);
			translate(g2, angle, DISTANCE_TO_PATCH, -1);
		}
		START_ANGLE += ANGLE_INC;
	}
    
	// translates the origin
	private void translate (Graphics2D g2, double angle, double distance, double sign) {
		g2.translate(sign*(Math.cos(angle)*distance), sign*(Math.sin(angle)*distance));
	}
	
	// draws a single patch centered around the origin
	private void drawPatch(Graphics2D g2) {
		int size = PATCH_SIZE;
		for (int i = 0; i < NUM_CIRC_FOR_PATCH; i++) {
			Color color= findColor(g2, i);
			g2.setColor(color);
			g2.fillOval(-size/2, -size/2, size, size);
			size -= PATCH_SIZE/NUM_CIRC_FOR_PATCH;
		}
	}

	// depending on which circle, find the color of the circle
	private Color findColor(Graphics2D g2, int x) {
		int red = START_RED + (x*RED_CHANGE);
		int green = START_GREEN - (x*GREEN_CHANGE);
		int blue = START_BLUE + (x*BLUE_CHANGE);
		Color color = new Color(red, green, blue);
		return color;
	}
}

class TitlePanel extends JPanel{
    
    private static final int PREFERRED_HEIGHT = 50;
    private static final int FONT_HEIGHT = 36;
    private static final String TITLE = "LILAC CHASER";
    
    private Color fontColor = new Color(130, 220, 130);
    private Font f = new Font(Font.SANS_SERIF, Font.BOLD + Font.ITALIC, FONT_HEIGHT);
    
    public TitlePanel(){
        setPreferredSize(new Dimension(LilacChaserPanel.PREFERRED_DIMENSION, PREFERRED_HEIGHT));
        setBackground(Color.WHITE);
    }
    
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
                RenderingHints.VALUE_ANTIALIAS_ON);
        
        // change color and font and draw string in the center
        g2.setColor(fontColor);
        g2.setFont(f);
        g2.drawString(TITLE,(int) ((LilacChaserPanel.SIZE_PANEL/2) - (266.0625/2)), (int) ((PREFERRED_HEIGHT/2)+(26.65625/2)));
    }
}