import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.Timer;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import a4Shell.*;

public class WatorFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private static final int MAX_FRAMES_PER_SECOND = 50;
    private static final int MIN_FRAMES_PER_SECOND = 5;
    private static final int DEFAULT_FRAMES_PER_SECOND = 30;
    
    private WatorPanel watorPanel;
    private GraphPanel graphPanel;
    private Timer timer; 
    
    public WatorFrame() {
        //  set up frame 
        setTitle("Wator World - Predator Prey Simulation");
        setLocation(50, 50);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        watorPanel = new WatorPanel();
        add(watorPanel);
        graphPanel = new GraphPanel(watorPanel.getWorld());
        add(graphPanel, "North");
        addTimer();
        addControlPanel();
        
        setResizable(false);
        pack();
        
    }
    
	public JButton getButton(String label, final int n){
        JButton result = new JButton(label);
        result.addActionListener(
        		createButtonListener(n));
        return result;
    }
    
	// create action listeners for bottom buttons
    public ActionListener createButtonListener(final int n) {
        return new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	// change indicators to show which button was pressed and repaint
            	if (n == 1) {
            		strt();
            	}
            	else if (n==2) {
            		stop();
            	}
            	else if (n==3) {
            		restart();
            	}
            	else {
            		watorPanel.human = true;
            	}
            }
        };
    }
    
    // post: create and add a slider to control time delay
    // based on code from Stuart Reges at UWCS
    
    // Add all the controls for the GUI.
    // Add a slider, and buttons to start and stop
    // the simulation. Add a button to reset the
    // simulation.
    
    // ** VERY IMPORTANT for CS324e students.**
    // For the assignment add one other control.
    // You choose what the control does.
    private void addControlPanel() {
        // slider to control frames per second
        final JSlider slider = new JSlider(MIN_FRAMES_PER_SECOND, MAX_FRAMES_PER_SECOND);
        slider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                timer.setDelay(1000 / slider.getValue());
            } });

        slider.setValue(DEFAULT_FRAMES_PER_SECOND);
        
        //  create a panel for the slider and its slow/fast labels 
        JPanel controlPanel = new JPanel();
        controlPanel.setPreferredSize(new Dimension(550, 40));
        controlPanel.add(new JLabel("slow"));
        controlPanel.add(slider);
        controlPanel.add(new JLabel("fast"));
        controlPanel.add(getButton("Start", 1));
        controlPanel.add(getButton("Stop", 2));
        controlPanel.add(getButton("Reset", 3));
        controlPanel.add(getButton("Human", 4));

        // *** CS324e Students. Add code here or a call to a helper method you
        // write to add the Start, Stop, and Reset buttons. ***
        
        add(controlPanel, "South");
    }    
    
    // post: Timer created
    private void addTimer(){
        timer = new Timer((int) (1000.0 / DEFAULT_FRAMES_PER_SECOND), 
                new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
            	watorPanel.update();
            	watorPanel.repaint();
            	graphPanel.update();
            	graphPanel.repaint();
            } });
        timer.setCoalesce(true); 
    }
    
    public void start(){
        setVisible(true);
    }
    
    public void strt() {
        timer.start();
        watorPanel.repaint();
        graphPanel.repaint();
    }
    
    public void stop(){
        timer.stop();
    }
    
    public void restart(){
    	timer.stop();
    	watorPanel.restart();
    	graphPanel.restart();
        watorPanel.repaint();
        graphPanel.repaint();
    }
}