import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import a4Shell.*;
import javax.swing.JPanel;

public class GraphPanel extends JPanel {

	private static final long serialVersionUID = 1L;

	// CS324e students: Add instance variables and constants
    // as necessary.
	private final int WIDTH = WatorPanel.WIDTH;
	private final double rows = WatorPanel.ROWS;
    private final int HEIGHT = 100;
    private final int total = WatorPanel.ROWS*WatorPanel.COLUMNS/HEIGHT;
    private int n = 0;
    
    private ArrayList<Integer> numFish;
    private ArrayList<Integer> numSharks;
    private WatorWorld theWorld;
    private Color green = new Color(8,247,0);
    private Color orange = new Color(247,206,16);
    
    public  GraphPanel(WatorWorld w){
        setBackground(Color.WHITE);
        
        // CS324e students - must change hard coded width
        // use constants or scaled values
        Dimension dim = new Dimension(WIDTH, HEIGHT);
        setPreferredSize(dim);
        
        theWorld = w;
        numSharks = new ArrayList<Integer>();
        numFish = new ArrayList<Integer>();
        
        // CS324e students, you must complete this constructor
    }

    
    public void update(){
    	int fish = theWorld.getNumFish();
        int shark = theWorld.getNumSharks();
        if (WatorPanel.human == true) {
        	numSharks.add((int) (shark*((100-n)/rows)));
            numFish.add((int) (fish*((100-n)/rows)));
        	n += 1;
        }
        else {
        	numSharks.add(shark);
        	numFish.add(fish);
        }
        // CS324e students, you must complete this method
    }

    
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
                RenderingHints.VALUE_ANTIALIAS_ON);
        g2.translate(0, HEIGHT);
        if (numSharks.size() > (WIDTH - 50)) {
        	int start = numSharks.size() - 500;
        	fillOval(g2, start); 
        }
        else {
        	fillOval(g2, 0); 
        }
        
        // CS324e students, you must complete this method
    }


	private void fillOval(Graphics g2, int j) {
		for (int i = 1; i+j < numSharks.size(); i++) {
    		double sharks1 = (numSharks.get(j+i-1) / total);
    		double sharks2 = (numSharks.get(j+i) / total);
    		double fish1 = (numFish.get(j+i-1)/ total);
    		double fish2 = (numFish.get(j+i)/ total);
    		g2.setColor(orange);
    		g2.drawLine(i-1, (int) -sharks1, i, (int) -sharks2);
    		g2.setColor(green);
    		g2.drawLine(i-1, (int) -fish1, i, (int) -fish2);
    	}
	}
    
    public void restart() {
    	numFish.clear();
    	numSharks.clear();	
    }
    
    // CS324e students: Add methods here as necessary
}
