import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.geom.Rectangle2D;
import java.util.Random;

import a4Shell.*;

import javax.swing.JPanel;

class WatorPanel extends JPanel{

    // CS324e students: Add instance variables and constants
    // as appropriate.

	private static final long serialVersionUID = 1L;
	private WatorWorld theWorld;
	private static int HEIGHT = 350;
	public static int WIDTH = 550;
	public static int ROWS = 100;
	public static int COLUMNS = 100;
	public static boolean human = false;
	public double n = 0;
	public int startFish = 4000;
	public int startShark = 1500;

    public WatorPanel(){
        setBackground(Color.BLUE);
        
        Dimension dim = new Dimension(WIDTH, HEIGHT);
        setPreferredSize(dim);


        // change values to constants or based on input from controls
        theWorld = new WatorWorld(ROWS, COLUMNS, startFish, startShark);

        // CS324e students, complete this constructor
    }

    public void update(){
    	theWorld.step();
    	if (human == true)
    		n += 1;
    }

    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
                RenderingHints.VALUE_ANTIALIAS_ON);
        double width = WIDTH;
        double height = HEIGHT;
        double x = width/(ROWS-1);
        double y = height/(COLUMNS-1);
        Color color = Color.BLUE;
        for (int i = 0; i < WIDTH; i++) {
        	for (int j = 0; j < HEIGHT; j++) {
        		double boxx = Math.floor(i/x);;
        		double boxy = Math.floor(j/y);
        		if (human == true) {
        			if((boxx < n) || (boxy < n))
        				color = Color.GRAY;
        			else 
        				color = theWorld.getColor((int) boxx, (int) boxy);
        		}
        		else {
        			color = theWorld.getColor((int) boxx, (int) boxy);
        		}
        		g2.setColor(color);
        		g2.fillRect(i, j, 1, 1);
        	}
        }

        // CS324e students. You must finish this method.
    }

    public WatorWorld getWorld(){
        return theWorld;
    }

	public void restart() {
		theWorld.reset(startFish,startShark);
		human = false;
    	n = 0;
	}

    // CS324e students: Add methods here as necessary
}
