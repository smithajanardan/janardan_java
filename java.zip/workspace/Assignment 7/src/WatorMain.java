//Student information for assignment.
//Student 1 Name: Smitha Janardan
//Student 1 UTEID: ssj398
// Student 2 Name: Zohaib Momin
// Student 2 UTEID: zpm66

//Slip days used:

//On our (my) honor Smitha Janardan and Zohaib Momin this
//assignments our (my) own work.

import java.util.Scanner;
import a4Shell.*;

/**
 * Class to kick off the Water World simulation and GUI.
 */
public class WatorMain {
    
    public static void main(String[] args) { 
        WatorFrame f = new WatorFrame(); 
        f.start(); 
    } 
    
    /*
     * This is a test method. It can be used to debug the non GUI 
     * portion of the simulation.
     */
    private static void testWithPrinting(){
        WatorWorld theWorld = new WatorWorld(20, 20, 350, 10);
        Scanner s = new Scanner(System.in);
        String response = null;
        do{
            System.out.println("number of fish: " + theWorld.getNumFish()
                    + ", number of sharks: " + theWorld.getNumSharks());
            System.out.println(theWorld);
            theWorld.step();
            System.out.println("Press enter to continue or any character and enter to stop.");
            response = s.nextLine();
        } while(response.length() < 2);
        
    }
}