// Student information for assignment.
// Student 1 Name: Smitha Janardan
// Student 1 UTEID: ssj398
// Student 2 Name: Zohaib Momin
// Student 2 UTEID: zpm66

// Slip days used:

// replace <Student1> and <Student2> with your names
// stating this is your own work.
// On our (my) honor Smitha Janardan and Zohaib Momin this
// assignment is our (my) own work.

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Point2D.Double;
import java.util.Arrays;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Bugs {

    public static void main(String[] args) {
        BugsFrame f = new BugsFrame();
        f.start();
    }
}

class BugsFrame extends JFrame {

    private BugsPanel thePanel;

    public BugsFrame(){
        final int SIZE = 450;

        setTitle("CS324E - Wriggling Bugs");
        setSize(SIZE, SIZE);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        thePanel = new BugsPanel();
        add(thePanel);
        this.setResizable(false); // must be before pack!
        pack();
    }


    public void start(){
        setVisible(true);
    }
}

class BugsPanel extends JPanel {

    private static final int SIZE = 600;
    private static final double BORDER_SIZE = SIZE / 30;
    private static final double SQUARE_SIZE = SIZE - 2 * BORDER_SIZE;
    private static final double BUG_SIZE = SIZE / 12;
    private static final double DISTANCE_CENTER_GROUP_TO_CENTER_BUG 
            = BUG_SIZE + BUG_SIZE / 4;   
    private static final double SMALL_CIRC_SIZE = BUG_SIZE / 5;
   
    private static final int BUGS_PER_GROUP = 6;
    private static final int NUM_ROWS = 3;

    private static final Color GREEN = new Color(153, 255, 0);
    private static final Color BLUE = new Color(0, 161, 255);
    private static final Color PURPLE = new Color(230, 0, 230);
    private static final Color YELLOW = new Color(255, 255, 0);
    
    // add instance variables and constants here
    
    public BugsPanel(){
        setBackground(Color.WHITE);
        this.setPreferredSize(new Dimension(SIZE, SIZE));
        // add necessary code
        
    }

    
    public void paintComponent(Graphics g){
        // do not change the following section
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
                RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setStroke(new BasicStroke(2));

        g2.setColor(GREEN);
        g2.fill(new Rectangle2D.Double(BORDER_SIZE, BORDER_SIZE, 
                SQUARE_SIZE, SQUARE_SIZE));

        drawGroup(g2);
 
    }

    // Moves the origin to the center of each group of bugs
	private void drawGroup(Graphics2D g2) {
		g2.translate(-(SIZE/(NUM_ROWS*2)),-(SIZE/(NUM_ROWS*2)));
		double increment = (SIZE/NUM_ROWS);
		int x = 0;
		for (int j = 0; j<NUM_ROWS; j++) {
			g2.translate(increment, 0);
			double y = 0;
            for (int i = 0; i<NUM_ROWS; i++) {
            	g2.translate (0, increment);
            	drawBugs(g2, x);
            	x += 1;
            }
            g2.translate(0, -SIZE);
        }
	}
	
	// translates the origin
	private void translate (Graphics2D g2, double angle, double distance, double sign) {
		g2.translate(sign*(Math.cos(angle)*distance), sign*(Math.sin(angle)*distance));
	}
	
	// finds the angle of the rotated bug
	private double findAngle(double angle, int x) {
		double angleBug = angle + Math.toRadians(-30);
		if ((x % 2) == 0) {
		}
		else {
			angleBug = angle - Math.PI + Math.toRadians(35);	
		}
		return angleBug;
	}
	
	// draw the a group of bugs around the center
	private void drawBugs(Graphics2D g2, int x) {
		double angleInc = (2*Math.PI)/BUGS_PER_GROUP;
		double angle = Math.toRadians(-15);
		for (int i = 0; i < BUGS_PER_GROUP; i++) {
			angle += angleInc;
			double angleBug = findAngle(angle, x);
			translate(g2, angle, DISTANCE_CENTER_GROUP_TO_CENTER_BUG, 1);
			drawBug(g2, angleBug);
			translate(g2, angle, DISTANCE_CENTER_GROUP_TO_CENTER_BUG, -1);
		}
	}

	// draws a single bug centered around the origin
	private void drawBug(Graphics2D g2, double angle) {
		g2.rotate(angle);
		drawAntenna(g2);
		drawBody(g2);
		drawSpots(g2);
		drawHead(g2);
		g2.rotate(-angle);
	}

	// draws the black and white arcs on the bug
	private void drawBorder(Graphics2D g2, double size) {
		Arc2D.Double boarder= new Arc2D.Double(-size/2, -size/2, size, size, 0, 180, Arc2D.OPEN);
        g2.setColor(Color.WHITE);
        g2.draw(boarder);
        Arc2D.Double boarder2= new Arc2D.Double(-size/2, -size/2, size, size, 0, -180, Arc2D.OPEN);
        g2.setColor(Color.BLACK);
        g2.draw(boarder2);
	}

	// draws the blue head thingy
	private void drawHead(Graphics2D g2) {
		g2.setColor(BLUE);
		Arc2D.Double head = new Arc2D.Double(-BUG_SIZE/2, -BUG_SIZE/2, BUG_SIZE, BUG_SIZE, 50, 80, Arc2D.CHORD);
		g2.fill(head);
	}

	//draws the bug spots and adds border
	private void drawSpots(Graphics2D g2) {
		g2.setColor(GREEN);
		g2.rotate(Math.toRadians(180));
		Ellipse2D.Double spot = new Ellipse2D.Double(-SMALL_CIRC_SIZE/2, -SMALL_CIRC_SIZE/2, SMALL_CIRC_SIZE, SMALL_CIRC_SIZE);
		g2.fill(spot);
		drawBorder(g2, SMALL_CIRC_SIZE);
		double dist = SMALL_CIRC_SIZE * 1.5;
		double [] angle = {30, -30, -90, 210, -210};
		for (int i = 0; i < 5; i++) {
			g2.setColor(GREEN);
			double radians = Math.toRadians(angle[i]);
			translate(g2, radians, dist, 1);
			g2.fill(spot);
			drawBorder(g2, SMALL_CIRC_SIZE);
			translate(g2, radians, dist, -1);
		}
		g2.rotate(-Math.toRadians(180));
	}

	// draws the purple body
	private void drawBody(Graphics2D g2) {
		g2.setColor(PURPLE);
		Ellipse2D.Double body = new Ellipse2D.Double(-BUG_SIZE/2, -BUG_SIZE/2, BUG_SIZE, BUG_SIZE);
		g2.fill(body);
		drawBorder(g2, BUG_SIZE);
	}

	// draws the antenna from the head
	private void drawAntenna(Graphics2D g2) {
		g2.setColor(YELLOW);
		g2.drawLine(0, (int) (-4*BUG_SIZE)/10, (int) -SMALL_CIRC_SIZE, (int) -((BUG_SIZE/2)+(SMALL_CIRC_SIZE/2)));
		g2.drawLine(0, (int) (-4*BUG_SIZE)/10, (int) SMALL_CIRC_SIZE, (int) -((BUG_SIZE/2)+(SMALL_CIRC_SIZE/2)));
	}

}