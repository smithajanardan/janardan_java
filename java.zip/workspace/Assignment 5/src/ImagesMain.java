//Student information for assignment.
//Student 1 Name: Smitha Janardan
//Student 1 UTEID: ssj398
// Student 2 Name: Zohaib Momin
// Student 2 UTEID: zpm66

//Slip days used:

//On our (my) honor Smitha Janardan and Zohaib Momin this
//assignments our (my) own work.

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;
import java.awt.image.LookupOp;
import java.awt.image.RescaleOp;
import java.awt.image.ShortLookupTable;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.TreeMap;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;

// A program to display the result of various image filters
public class ImagesMain {
    public static void main(String[] args) { 
        try{
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch(Exception e){
            System.out.println("Unable to change look and feel");
        }
        ImagesFrame f = new ImagesFrame(); 
        f.start(); 
    } 
} // end of ImagesMain class

class ImagesFrame extends JFrame{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ImagesPanel panel;
    private JFileChooser fileChooser;
    
    public ImagesFrame() {
        super("Image Filtering");
        setSize(800, 700);
        setLocation(100, 100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        panel = new ImagesPanel();
        add(panel);
        createFileChooser();
        add(createButton(), "North");
        
        addMenu();
        addMouseListener(new ColorPicker());
    }
    
    private class ColorPicker extends MouseAdapter {
        private Robot r;
        
        ColorPicker() {
            try {
                r = new Robot();
            }
            catch(AWTException e) {
                System.out.println(e);
            }
        }
        
        public void mouseClicked(MouseEvent e) {
            
            // robot uses absolute coordinates
            // mouse event gives relative coordiantes
            // so need to adjust to get correct location
            Color pixelColor = r.getPixelColor(e.getX() + getX(), 
                    e.getY() + getY());
            panel.setColor(pixelColor);
            panel.repaint();
            // debugging code
            // System.out.println(e);
            // System.out.println("pixel color: " + pixelColor);
        }
        
    }
    
    // for choosing files
    // when the new file button is pressed the user
    // browsers their system for a new image
    private void createFileChooser(){
        fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select Image File to Process");
        
        FileNameExtensionFilter imageFiles 
            = new FileNameExtensionFilter("Image Files", "jpg", "JPG", "GIF", "gif", "PNG", "png", "jpeg", "JPEG");
        fileChooser.setFileFilter(imageFiles);
    }
    
    // when this button is pressed the user will
    // browse their system for a new image
    private JButton createButton(){
        JButton result = new JButton("New Picture");
        result.addActionListener(new ActionListener(){ 
            public void actionPerformed(ActionEvent e){
                int retval = fileChooser.showOpenDialog(ImagesFrame.this);
                if (retval == JFileChooser.APPROVE_OPTION) {
                    panel.readImage(fileChooser.getSelectedFile());
                    panel.repaint();
                }
            }
        });
        return result;
    }
    
    // The menu contains the various filters.
    // The Transforms menu contains filters that are
    // implementations of BufferedImageOp.
    // The Filters menu contains filters that are 
    // implementations of the custom FilterOps class 
    // which is shown below.
    private void addMenu(){
        JMenuBar mb = new JMenuBar();
        setJMenuBar(mb);
        JMenu menu = new JMenu("Transforms");
        mb.add(menu);
        
        for(String s : ImagesPanel.IMAGE_OPS){
            JMenuItem mi = new JMenuItem(s);
            mi.addActionListener(getActionListener());
            menu.add(mi);
        }
        
        JMenu menu2 = new JMenu("Filters");
        mb.add(menu2);
        for(String s : ImagesPanel.FILTER_OPS){
            JMenuItem mi = new JMenuItem(s);
            mi.addActionListener(getActionListener());
            menu2.add(mi);            
        }
    }
    
    private ActionListener getActionListener(){
        return new ActionListener(){
            public void actionPerformed(ActionEvent event){
                panel.setImageOp(event.getActionCommand());
                panel.repaint();
            }
        };
    }
    
    
    public void start(){
        setVisible(true);
    }
} // end of ImagesFrame class


class ImagesPanel extends JPanel{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static final String[] IMAGE_OPS = 
            {"Rescale", "Lookup", "Blur", "Sharpen", "Edge", "Emboss", 
             "Invert", "Threshold", "Mirror", "Gaussian", "Posterize", 
             "Red Only"};

    public static final String[] FILTER_OPS = {"Grayscale", 
        "Grayscale Naive", "Simplify", 
        "Black and White", "Hot Metal",
        "Censor", "Color Pop", "Sepia Tone",
        "Edge Blur", "Student Filter - Worn"};
    
    // so menus are in sorted order
    static {
        Arrays.sort(IMAGE_OPS);
        Arrays.sort(FILTER_OPS);
    }
    

    private TreeMap<String, BufferedImageOp> imageOps;
    private TreeMap<String, FilterOp> filterOps;
    private BufferedImage originalImage;
    private BufferedImage filteredImage;
    private String currentOp;

    public ImagesPanel(){
        currentOp = "Sharpen";
        createImageOps();
        createFilterOps();
    }

    public void setColor(Color pixelColor) {
        if(currentOp.equals("Color Pop")) {
            ColorPop cp = (ColorPop) filterOps.get("Color Pop");
            cp.setColor(pixelColor.getRGB());
            filteredImage = cp.filter(originalImage);
        }
    }

    public void setImageOp(String opName){
        currentOp = opName;
        BufferedImageOp bio = imageOps.get(opName);
        if(bio != null) {
            if(opName.equals("Mirror")) 
                // special case because translation depends on image size!
                filteredImage = mirrorImage();
            else
                filteredImage = bio.filter(originalImage, null);
        }
        else{
            // user picked a filter op
            FilterOp fo = filterOps.get(opName);
            if(fo != null)
                filteredImage = fo.filter(originalImage);
        }
    }

    private BufferedImage mirrorImage() {
        AffineTransform at = new AffineTransform();
        at.translate(originalImage.getWidth(), 0);
        at.scale(-1, 1);
        AffineTransformOp result 
            = new AffineTransformOp(at, 
                    AffineTransformOp.TYPE_BICUBIC);
        return result.filter(originalImage, null);
    }

    public void readImage(File f){
        Toolkit tk = Toolkit.getDefaultToolkit();
        Image img = tk.getImage(f.getPath());
        MediaTracker tracker = new MediaTracker(new Component() {

			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;});
        tracker.addImage(img, 0);
        try {
            tracker.waitForID(0);
        } catch (InterruptedException ex) {}
        originalImage = new BufferedImage(img.getWidth(this), img.getHeight(this), BufferedImage.TYPE_INT_RGB);
        originalImage.getGraphics().drawImage(img, 0, 0, this);
        filteredImage = imageOps.get("Sharpen").filter(originalImage, null);
    }

    private void createFilterOps(){
        filterOps = new TreeMap<String, FilterOp>();
        filterOps.put("Grayscale", new Grayscale());
        filterOps.put("Grayscale Naive", new GrayscaleNaive());
        filterOps.put("Simplify", new Simplify());
        filterOps.put("Black and White", new BlackAndWhite());
        filterOps.put("Hot Metal", new HotMetal());
        filterOps.put("Sepia Tone", new SepiaTone());
        filterOps.put("Edge Blur", new EdgeBlur());
        filterOps.put("Student Filter - Worn", new Worn());
        filterOps.put("Censor", new Censor());
        filterOps.put("Color Pop", new ColorPop(65));
       
    }

    private void createImageOps(){
        imageOps = new TreeMap<String, BufferedImageOp>();
        imageOps.put("Rescale", getRescaleOp());
        imageOps.put("Lookup", createLookupOp());
        imageOps.put("Blur", getBlur());
        imageOps.put("Sharpen", getSharpen());
        imageOps.put("Edge", getEdge());
        imageOps.put("Emboss", getEmboss());
        imageOps.put("Invert", new RescaleOp(-1, 255, null));
        imageOps.put("Threshold", createThresholdLookup());
        imageOps.put("Red Only", createRedOnly());
        imageOps.put("Posterize", createPosterize());
        imageOps.put("Gaussian", createGaussian());
        
        // put dummy value in map, because we actually create
        // new BufferedImageOp based on current image 
        imageOps.put("Mirror", getEmboss());   
    }
    
    private BufferedImageOp createRedOnly() {
        float[] scales = {1f, 0f, 0f};
        float[] offsets = {0, 0, 0};     
        return new RescaleOp(scales, offsets, null);
    }
    
    private LookupOp createPosterize(){
        final int SIZE = 256;
        short[] values = new short[SIZE];      
        for (int i = 0; i < SIZE; i++){
        	if (i < 32)
        		values[i] = 0;
        	else if (i < 96)
        		values[i] = 64;
        	else if (i < 160)
        		values[i] = 128;
        	else if (i < 224)
        		values[i] = 192;
        	else
        		values[i] = 255;
        }
        short[][] table = {values, values, values};
        ShortLookupTable pTable = new ShortLookupTable(0, table);
        LookupOp lookup = new LookupOp(pTable, null);
        return lookup;  
    }
    
    private BufferedImageOp createGaussian() {
    	int size = 7;
        float[] kernelValues = new float[]{1f, 34f, 285f, 579f, 285f, 34f, 1f,
        	34f, 1174f, 9791f, 19856f, 9791f, 1174f, 34f,
        	285f, 9791f, 81674f, 165644f, 81674f, 9791f, 285f,
        	579f, 19856f, 165644f, 335946f, 165644f, 19856f, 579f,
        	285f, 9791f, 81674f, 165644f, 81674f, 9791f, 285f,
        	34f, 1174f, 9791f, 19856f, 9791f, 1174f, 34f,
        	1f, 34f, 285f, 579f, 285f, 34f, 1f};
        for (int i = 0; i < (size*size); i++) {
        	kernelValues[i] = kernelValues[i] / 1492538f;        	
        }
        return new ConvolveOp(new Kernel(size, size, kernelValues));
    }
    
    private BufferedImageOp getEmboss() {
        float[] kernelValues = new float[]{-2, -1, 0, -1, 1, 1, 0, 1, 2};
        return new ConvolveOp(new Kernel(3, 3, kernelValues));
    }
    
    private BufferedImageOp getEdge() {
        float[] kernelValues = new float[]{-1, 0, -1, 0, 4, 0, -1, 0, -1};
        return new ConvolveOp(new Kernel(3, 3, kernelValues));
    }
    
    private BufferedImageOp getSharpen() {
        float[] kernelValues = new float[]{0, -1, 0, -1, 5, -1, 0, -1, 0};
        return new ConvolveOp(new Kernel(3, 3, kernelValues));
    }
    
    private BufferedImageOp getBlur() {
        // for convolve ops
        float[] kernelValues = new float[9];
        Arrays.fill(kernelValues, 1 / 9.0f); 
        return new ConvolveOp(new Kernel(3, 3, kernelValues));
    }
    
    private BufferedImageOp getRescaleOp() {
        float[] scales = {0.5f, 1.7f, 0.5f};
        float[] offsets = {0, 0, 0};     
        return new RescaleOp(scales, offsets, null);
    }
    
    private LookupOp createThresholdLookup() {
        short[] values = new short[256];
        int THRESHOLD = 70;
        for(int i = THRESHOLD; i < values.length; i++)
            values[i] = 255;
        return new LookupOp(new ShortLookupTable(0, values), null);
    }

    private LookupOp createLookupOp(){
        final int SIZE = 256;
        final int THRESHOLD = 150;
        short[] redValues = new short[SIZE];
        short[] greenValues = new short[SIZE];
        short[] blueValues = new short[SIZE];
        for(int i = 0; i < SIZE; i++){
            if(i < THRESHOLD){
                greenValues[i] = (short)(Math.sqrt(i));
                blueValues[i] = (short)(Math.sqrt(i));
            }
            else{
                greenValues[i] = (short)(Math.min(Math.pow(i, 1.05), SIZE - 1));
                blueValues[i] = (short)(Math.min(Math.pow(i, 1.05), SIZE - 1));
            }
            redValues[i] = (short)(Math.min(Math.pow(i, 1.05), SIZE - 1));
        }
        short[][] table = {redValues, greenValues, blueValues};
        ShortLookupTable colorTable = new ShortLookupTable(0, table);
        LookupOp lookup = new LookupOp(colorTable, null);
        return lookup;  
    }


    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;

        if(originalImage != null) {            
            double scale = getScale();
            int drawWidth = (int)(originalImage.getWidth() * scale);
            int drawHeight = (int)(originalImage.getHeight() * scale);
            // draw original image on left and filtered image on right
            g2.drawImage(originalImage, 0, 0, drawWidth, drawHeight, null);
            g2.drawImage(filteredImage, drawWidth, 0, drawWidth, drawHeight, null);
        }
    }
    
    // method to determine how to scale image. Retain
    // proportion, but shrink or grow image as necessary
    private double getScale() {
        final int MAX_WIDTH = getWidth() / 2;
        final int MAX_HEIGHT = getHeight();
        double xScale = 1.0 * MAX_WIDTH / originalImage.getWidth();
        double yScale = 1.0 * MAX_HEIGHT / originalImage.getHeight();
        
        return Math.min(xScale, yScale);
    }
} // end of ImagesPanel class


abstract class FilterOp {
    
    public abstract int filterOp(int x, int y, int pixel, BufferedImage src);
    
    public BufferedImage filter(BufferedImage src){
        BufferedImage result = new BufferedImage(src.getWidth(), src.getHeight(), src.getType());
        for(int x = 0; x < src.getWidth(); x++)
            for(int y = 0; y < src.getHeight(); y++)
                result.setRGB(x, y, filterOp(x, y, src.getRGB(x, y), src));
        return result;
    }
    
    /**
     * Extracts the red component of a pixel.
     * @param pixel an integer pixel
     * @return  the red component [0-255] of the pixel.
     */
    public static int getRed(int pixel) {
        return pixel >> 16 & 0xff;
    }

    /**
     * Extracts the green component of a pixel.
     * @param pixel an integer pixel
     * @return  the green component [0-255] of the pixel.
     */
    public static int getGreen(int pixel) {
        return pixel >> 8 & 0xff;
    }

    /**
     * Extracts the blue component of a pixel.
     * @param pixel an integer pixel
     * @return  the blue component [0-255] of the pixel.
     */
    public static int getBlue(int pixel) {
        return pixel & 0xff;
    }
    
    /**
     * Extracts all components of a pixel.
     * @param pixel an integer pixel
     * @return  an array with r, g, b values. r is at index 0
     * g is at index 1, and b is at index 2.
     */    
    public static int[] getRGB(int pixel) {
        return new int[]{getRed(pixel), getGreen(pixel), getBlue(pixel)};
    }
    
    /**
     * Constructs a pixel from RGB components.
     * @param red   the red component [0-255]
     * @param green the green component [0-255]
     * @param blue  the blue component [0-255]
     * @return  the packed integer pixel.
     */
    public static int makePixel(int red, int green, int blue) {
        return (red & 0xff) << 16 | (green & 0xff) << 8 | (blue & 0xff);
    }
} // end of FilterOp class

class SepiaTone extends FilterOp {
    
    public int filterOp(int x, int y, int pixel, BufferedImage src){
        int r = getRed(pixel);
        int g = getGreen(pixel);
        int b = getBlue(pixel);
        int outputRed = (int) (0.393 * r + 0.769 * g + 0.189 * b);
        int outputGreen = (int) (0.349 * r + 0.686 * g + 0.168 * b);
        int outputBlue = (int) (0.272 *r + 0.534 * g + 0.131 * b);
        outputRed = colorScale(outputRed);
        outputGreen = colorScale(outputGreen);
        outputBlue = colorScale(outputBlue);
        return makePixel(outputRed, outputGreen, outputBlue);
    }

    // cap the color at 255
	private int colorScale(int color) {
		if (color > 255)
			color = 255;
		return color;
	}
} // end of SepiaTone class

class Censor extends FilterOp {
	
	static public int size = 10;
    
    public int filterOp(int x, int y, int pixel, BufferedImage src){
    	// find the box number
    	int widthsp = src.getWidth()/size;    	
    	int boxx = x/widthsp;
    	int boxy = y/widthsp;
    	int pix = CensorConvolve(boxx, boxy, widthsp, src);
    	return pix;
    }
    
    // based on box number, average the color in each box
    private static int CensorConvolve(int x, int y, int n, BufferedImage src) {
		int avgr = 0;
		int avgg = 0;
		int avgb = 0;
		int xstart = (x)*n;
		int ystart = (y)*n;
		for (int i = xstart; i < n+xstart; i++) {
			for (int j = ystart; j < n+ystart; j++) {
				if (i < src.getWidth() && j < src.getHeight()) {
					int pixel2 = src.getRGB(i, j);
	   				avgr += getRed(pixel2);
	   				avgg += getGreen(pixel2);
	   				avgb += getBlue(pixel2);
				}
			}
		}
		avgr = avgr / (n*n);
		avgg = avgg / (n*n);
		avgb = avgb / (n*n);
		return makePixel(avgr, avgg, avgb);
    }
} // end of Censor class

class EdgeBlur extends FilterOp {
    
    public int filterOp(int x, int y, int pixel, BufferedImage src){
    	int cx = src.getWidth()/2;
    	int cy = src.getHeight()/2;
    	double maxD = Math.sqrt(Math.pow(cx, 2) + Math.pow(cy, 2));
    	double third = maxD / 3;
    	double second  = 2*maxD / 3;
    	double distance = Math.sqrt(Math.pow(x-cx, 2) + Math.pow(y-cy, 2));
        int pix = pixel;
    	if (distance > second) {
    		pix = BlurConvolve(x,y,13,src);
    	}
    	else if (distance > third) {
    		pix = BlurConvolve(x,y,7,src);	
    	}
		return pix;
    }
    
    // for each pixel, average the surrounding colors
    private static int BlurConvolve(int x, int y, int n, BufferedImage src) {
		int avgr = 0;
		int avgg = 0;
		int avgb = 0;
		int n2 = n/2;
		for (int i = x-n2; i < x+n2+1; i++) {
			for (int j = y-n2; j < y+n2+1; j++) {
				if (i > 0 && j > 0 && i < src.getWidth() && j < src.getHeight()) {
					int pixel2 = src.getRGB(i, j);
   					avgr += getRed(pixel2);
   					avgg += getGreen(pixel2);
   					avgb += getBlue(pixel2);
				}
			}
		}
		avgr = avgr / (n*n);
		avgg = avgg / (n*n);
		avgb = avgb / (n*n);
		return makePixel(avgr, avgg, avgb);
    }
} // end of EdgeBlur class

class Worn extends FilterOp {
    
    public static final int BLACK  = makePixel(10, 10, 30);
    public static final int WHITE = makePixel(255,255,255);
    public static final Random randNumGen = new Random();
    
    public int filterOp(int x, int y, int pixel, BufferedImage src){
    	// make image blank and white
        int r = getRed(pixel);
        int g = getGreen(pixel);
        int b = getBlue(pixel);
        int gray = (int)(0.333 * r + 0.333 * g + 0.333 * b);
        int pix = makePixel(gray, gray, gray);
        // make some pixels white and some black
        int rn = randNumGen.nextInt(100);
        if(rn < 7)
            pix = BLACK;
        else if (rn > 93)
        	pix = WHITE;
        return pix;
    }
} //end of Worn class

class Simplify extends FilterOp {
    
    public static final int BLACK = makePixel(0, 0, 0);
    public static final int WHITE = makePixel(255, 255, 255);
    public static final int RED = makePixel(255, 0, 0);
    public static final int GREEN = makePixel(0, 255, 0);
    public static final int BLUE = makePixel(0, 0, 255);
    
    public int filterOp(int x, int y, int pixel, BufferedImage src){
        final int LOW_THRESHOLD = 50;
        final int HIGH_THRESHOLD = 200;
        
        int result = BLUE;
        int r = getRed(pixel);
        int g = getGreen(pixel);
        int b = getBlue(pixel);
        if( r < LOW_THRESHOLD && g < LOW_THRESHOLD && b < LOW_THRESHOLD)
            result = BLACK;
        else if (r > HIGH_THRESHOLD && g > HIGH_THRESHOLD && b > HIGH_THRESHOLD)
            result = WHITE;
        else if(r > g && r > b)
            result = RED;
        else if( g > r && g > b)
            result = GREEN;
        return result;
    }
} // end of Simplify class

class GrayscaleNaive extends FilterOp {

    public int filterOp(int x, int y, int pixel, BufferedImage src){
        int r = getRed(pixel);
        int g = getGreen(pixel);
        int b = getBlue(pixel);
        int gray = (int)(0.333 * r + 0.333 * g + 0.333 * b);
        return makePixel(gray, gray, gray);
    }
} // end of GrayscaleNaive class

class Grayscale extends FilterOp {

    public int filterOp(int x, int y, int pixel, BufferedImage src){
        int r = getRed(pixel);
        int g = getGreen(pixel);
        int b = getBlue(pixel);
        int gray = (int)(0.3 * r + 0.59 * g + 0.11 * b);
        return makePixel(gray, gray, gray);
    }
} // end of Gray-scale class


class BlackAndWhite extends FilterOp {

    public int filterOp(int x, int y, int pixel, BufferedImage src){
        int r = getRed(pixel);
        int g = getGreen(pixel);
        int b = getBlue(pixel);
        int min = 127;
        boolean aboveThreshold = r > min || g > min || b > min;
        return aboveThreshold ? makePixel(255, 255, 255) : makePixel(0, 0, 0);
    }
} // end of BlackAndWhite class


class HotMetal extends FilterOp {
    
    private int[] values;
    
    public HotMetal() {
        values = new int[256];
        final int MAX_RED = 170;
        for(int i = 0; i < values.length; i++) {
            int red = (int) Math.min(1.0 * i / MAX_RED * 255, 255);
            int green = i - MAX_RED;
            green = green <= 0 ? 0 : (short) Math.min(1.0 * green / 85 * 255, 255);
            values[i] = makePixel(red, green, 0);
        }
    }
    
    public int filterOp(int x, int y, int pixel, BufferedImage src){
        int r = getRed(pixel);
        int g = getGreen(pixel);
        int b = getBlue(pixel);
        int gray = (int)(0.3 * r + 0.59 * g + 0.11 * b);
        return values[gray];
    }    
} // end of HotMetal class

class ColorPop extends FilterOp {

    public ColorPop(int d) {
        distance = d;
    }
   
    private int[] rgb;
    private int distance;
   
    public void setColor(int color) {
        rgb = getRGB(color);
    }
   
    @Override
    public int filterOp(int x, int y, int pixel, BufferedImage src) {
        // complete and change return value
        int r1= rgb[0];
        int g1= rgb[1];
        int b1= rgb[2];
        int r = getRed(pixel);
        int g = getGreen(pixel);
        int b = getBlue(pixel);
        int dPixel= (int) Math.sqrt(Math.pow((r1-r),2) + Math.pow((g1-r),2) + Math.pow((b1-b),2));
        if (dPixel >= distance){
            int gray = (int)(0.3 * r + 0.59 * g + 0.11 * b);
            return makePixel(gray, gray, gray);
        }
        return makePixel(r1, g1, b1);
    }
} // end of ColorPop class