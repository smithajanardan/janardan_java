FourByFour

To run:

    appletviewer FourByFour.html

Press the "Instructions" button to get instructions on
how to play FourByFour.
