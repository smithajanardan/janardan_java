// Student information for assignment.
// Student 1 Name: Smitha Janardan
// Student 1 UTEID: ssj398

// Slip days used: 

// On my honor, Smitha Janardan,  this
// assignment is my own work.

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GraphicsConfiguration;
import java.util.ArrayList;
import java.util.Arrays;
import javax.media.j3d.Alpha;
import javax.media.j3d.AmbientLight;
import javax.media.j3d.Appearance;
import javax.media.j3d.Background;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Canvas3D;
import javax.media.j3d.DirectionalLight;
import javax.media.j3d.GeometryArray;
import javax.media.j3d.Material;
import javax.media.j3d.PointLight;
import javax.media.j3d.PolygonAttributes;
import javax.media.j3d.PositionPathInterpolator;
import javax.media.j3d.QuadArray;
import javax.media.j3d.RotationInterpolator;
import javax.media.j3d.ScaleInterpolator;
import javax.media.j3d.Shape3D;
import javax.media.j3d.SpotLight;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.media.j3d.View;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.vecmath.Color3f;
import javax.vecmath.Point3d;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector3f;
import com.sun.j3d.utils.behaviors.vp.OrbitBehavior;
import com.sun.j3d.utils.geometry.ColorCube;
import com.sun.j3d.utils.geometry.Cylinder;
import com.sun.j3d.utils.geometry.Sphere;
import com.sun.j3d.utils.geometry.Text2D;
import com.sun.j3d.utils.universe.SimpleUniverse;
import com.sun.j3d.utils.universe.ViewingPlatform;

public class Java3D_DIY extends JFrame {
    
	private static final long serialVersionUID = 1L;

	public Java3D_DIY() {
        super("Java3D DIY");
        add(new WrapCheckers3D());
        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        setResizable(false);
        pack();     
        setVisible(true);
    } 
    
    public static void main(String[] args)
    { new Java3D_DIY(); }
}

class WrapCheckers3D extends JPanel {
	private static final long serialVersionUID = 1L;
	private static final int PWIDTH = 800;   
    private static final int PHEIGHT = 600; 
    private static final int BOUNDSIZE = 100;  
    private static final Point3d USERPOSN = new Point3d(0,5,80); 
    private static final Color3f yellow = new Color3f(0.9375f, 0.9609f, 0.2423f);
    private static final Color3f lightyellow = new Color3f(1.0f, 1.0f, 0.7765f);
    private static final Color3f black = new Color3f(0.0f, 0.0f, 0.0f);
    private static final Color3f grey = new Color3f(0.8980f, 0.8118f, 0.6510f);
    private static final Color3f burgandy = new Color3f(0.7216f, 0.3020f, 0.0824f);
    private static final Color3f lightblue = new Color3f(0.6196f, 0.8078f, 0.8471f);
    private static final Color3f darkblue = new Color3f(0.1922f, 0.3529f, 0.5333f);

    // instance variables
    private SimpleUniverse su;
    private BranchGroup sceneBG;
    private BoundingSphere bounds;

    public WrapCheckers3D() {

        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(PWIDTH, PHEIGHT));

        GraphicsConfiguration config =
            SimpleUniverse.getPreferredConfiguration();
        Canvas3D canvas3D = new Canvas3D(config);
        add(canvas3D);
        canvas3D.setFocusable(true);     

        su = new SimpleUniverse(canvas3D);

        createSceneGraph();
        initUserPosition();        
        orbitControls(canvas3D);   

        su.addBranchGraph(sceneBG);
    }

    private void orbitControls(Canvas3D canvas3d) {
        
        // to move the view point in the same direction as mouse
        OrbitBehavior orbit = new OrbitBehavior(canvas3d, 
            OrbitBehavior.REVERSE_ALL);
            
        orbit.setSchedulingBounds(bounds);
        ViewingPlatform vp = su.getViewingPlatform();
        vp.setViewPlatformBehavior(orbit);
    }

    private void createSceneGraph() {

        sceneBG = new BranchGroup();
        bounds = new BoundingSphere(new Point3d(0,0,0), BOUNDSIZE);   

        lightScene();         
        addBackground();      
        //sceneBG.addChild( new CheckerFloor().getBG() ); 
        TransformGroup pathGroup = new TransformGroup();
        Alpha pathAlpha = new Alpha(-1,
                Alpha.DECREASING_ENABLE | Alpha.INCREASING_ENABLE,
                0, // triggerTime
                0, // phaseDelayDuration
                4000, // increasing Alpha duration
                0, // increasing ramp duration
                1000, // time at one
                2000, // decreasing Alpha duration
                0, // decreasing ramp duration
                3000); // time at zero
        float[] knot = {0.0f, 1.0f, 1.0f};
        Point3f[] points = {new Point3f(-1, 10, 7), new Point3f(-2,-7,-4), new Point3f(8,-2,9)};
        PositionPathInterpolator path = new PositionPathInterpolator(pathAlpha, pathGroup, new Transform3D(), knot, points);
        path.setSchedulingBounds(bounds);
        pathGroup.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
        pathGroup.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
        pathGroup.addChild(path);
        sceneBG.addChild(pathGroup);
        TransformGroup planets = new TransformGroup(new Transform3D());
        addPlanets(planets);
        Transform3D spinner = new Transform3D();
        spinner.rotZ(0);
        Alpha rotationAlpha = new Alpha(-1,16000);   // 4 secs
        RotationInterpolator rotator = 
            new RotationInterpolator(rotationAlpha, planets, 
            		spinner, 0.0f, (float) Math.PI*2.0f);
        rotator.setSchedulingBounds(
                new BoundingSphere( new Point3d(0,0,0), 100.0) );
        planets.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
        pathGroup.addChild(planets);
        planets.addChild(rotator);
        sceneBG.compile();   
    } 
    
    private void addPlanet(TransformGroup planets, float x, float y, float z, 
    		Color3f color1, Color3f color2, float n, float size, boolean rings) {
    	Transform3D planet = new Transform3D();
    	planet.setTranslation(new Vector3f(x, y, z));
    	TransformGroup planetGroup = new TransformGroup(planet);
    	planets.addChild(planetGroup);
		Appearance surface = new Appearance(); 
		surface.setMaterial(new Material(color1, color2, color1, color2, n));
		Sphere sphere = new Sphere(size, surface);
        planetGroup.addChild(sphere);
        if (rings == true) {
        	Cylinder cylinder = new Cylinder(size+(size/3), 0.0001f, surface);
        	planetGroup.addChild(cylinder);
        }
    }

	private void addPlanets(TransformGroup planets) {
		addPlanet(planets, 0f, 0f, 0f, yellow, black, 10f, 3f, false);
		addPlanet(planets, 4f, -4f, 4f, grey, black, 10f, 0.5f, false);
		addPlanet(planets, 8f, 1f, -8f, grey, black, 10f, 0.5f, false);
		addPlanet(planets, -12f, 0f, 12f, lightblue, black, 30f, 0.5f, false);
		addPlanet(planets, 16f, -2f, -16f, burgandy, black, 30f, 0.5f, false);
		addPlanet(planets, 20f, -3f, 20f, lightyellow, black, 30f, 0.5f, false);
		addPlanet(planets, -24f, 1f, -24f, grey, black, 30f, 0.5f, true);
		addPlanet(planets, -28f, 4f, -28f, lightblue, black, 30f, 0.5f, false);
		addPlanet(planets, 32f, 3f, 32f, darkblue, black, 30f, 0.5f, false);
		addPlanet(planets, -40f, 4f, 40f, darkblue, black, 30f, 0.5f, false);
	}

	private void addBackground() {
        Background back = new Background();
        back.setApplicationBounds(bounds);
        back.setColor(0.0f, 0.0f, 0.0f); 
        sceneBG.addChild(back);
    }  

    private void lightScene() {
        
        Color3f white = new Color3f(1, 1, 1);
        AmbientLight ambientLightNode = new AmbientLight(white);
        ambientLightNode.setInfluencingBounds(bounds);
        sceneBG.addChild(ambientLightNode);

        // Set up the directional lights

        // pointing left, down, into scene 
        Vector3f light1Direction  
            = new Vector3f(-1, -1, -1);     
        Color3f yellow = new Color3f(1, 1, 0);
        DirectionalLight light1 = 
            new DirectionalLight(yellow, light1Direction);
        light1.setInfluencingBounds(bounds);
        sceneBG.addChild(light1);
    
        // point right, down, out of scene   
        Vector3f light2Direction  
            = new Vector3f(1.0f, -1.0f, 1.0f);
        Color3f magenta = new Color3f(1, 0, 1);
        DirectionalLight light2 = 
            new DirectionalLight(magenta, light2Direction);
        light2.setInfluencingBounds(bounds);
        sceneBG.addChild(light2);

//        // sample code for point lights and spot lights
        Color3f cyan = new Color3f(1, 1, 1);
        Point3f higher = new Point3f(1, 20, -1);
        Point3f attenuation = new Point3f(1, .05f, .001f);
        PointLight highLight = new PointLight(cyan, higher, attenuation);
        highLight.setInfluencingBounds(bounds);
        sceneBG.addChild(highLight);
      
//        
        // Point3f attenuation = new Point3f(1, .05f, .001f);
        Point3f pos = new Point3f(0, 10, 5);
        Vector3f direction = new Vector3f(0, -.5f, -1);
        SpotLight spot = new SpotLight(white, pos, 
                attenuation, direction, (float)(Math.PI * .25), 100); 
        
        spot.setInfluencingBounds(bounds);
        sceneBG.addChild(spot);


    } 

    private void initUserPosition() {
        // necessary to get the Transform group for the 
        // viewing platform in order to position it.
        ViewingPlatform vp = su.getViewingPlatform();
        TransformGroup steerTG = vp.getViewPlatformTransform();

        Transform3D t3d = new Transform3D();
        //  Copies the transform component of the TransformGroup 
        // into the passed transform object. (So we can
        // move it.)
        steerTG.getTransform(t3d);

        // args are: viewer posn, where looking, up direction
        // recall USERPOSN is (0, 5, 20) // x, y, z
        t3d.lookAt( USERPOSN, new Point3d(0,0,0), new Vector3d(0,1,0));
        t3d.invert();

        steerTG.setTransform(t3d);
        changeClips();
    }  
    
    private void changeClips() {
        // change back clip distance
        View view = su.getViewer().getView();
        System.out.println("Clip distance: " + view.getBackClipDistance());
        view.setBackClipDistance(view.getBackClipDistance() * 3);
        view.setFrontClipDistance(0.5);        
    }
}

class CheckerFloor {
    private final static int FLOOR_SIZE = 120;

    // tile colors
    private final static Color3f blue = new Color3f(0.0f, 0.1f, 0.4f);
    private final static Color3f green = new Color3f(0.0f, 0.5f, 0.1f);

    // colors for axis and text
    private final static Color3f medRed = new Color3f(0.8f, 0.4f, 0.3f);
    private final static Color3f white = new Color3f(1.0f, 1.0f, 1.0f);

    // single instance variable, to be able to add to scene graph
    private BranchGroup floorBG;
    
    // constructor for the CheckFloor class. 
    public CheckerFloor() {
        ArrayList<Point3f> blueCoords = new ArrayList<Point3f>();
        ArrayList<Point3f> greenCoords = new ArrayList<Point3f>();
        floorBG = new BranchGroup();

        boolean isBlue = false;
        // create coordinates of tiles. Each tile is 1 unit by 1 unit
        final int LIMIT = (FLOOR_SIZE / 2) - 1;
        for(int z = -FLOOR_SIZE / 2; z <= LIMIT; z++) {
            isBlue = !isBlue;
            for(int x = -FLOOR_SIZE / 2; x <= LIMIT; x++) {
                Point3f[] points = createCoords(x, z);
                ArrayList<Point3f> addTo 
                    = isBlue ? blueCoords : greenCoords;
                for(Point3f p : points)
                    addTo.add(p);
                isBlue = !isBlue;
            }
        }
        floorBG.addChild( new ColoredTiles(blueCoords, blue) );
        floorBG.addChild( new ColoredTiles(greenCoords, green) );

        addOriginMarker();
        labelAxes();
    }
    
    private void labelAxes(){
        final int LIMIT = FLOOR_SIZE / 2;
        Vector3d pt = new Vector3d();
        for(int i = -LIMIT; i <= LIMIT; i++){
            pt.z = 0;
            pt.x = i;
            floorBG.addChild( makeText(pt, "" + i) );
            pt.x = 0;
            pt.z = i;
            floorBG.addChild( makeText(pt, "" + i) );
        }
    }
    
    private TransformGroup makeText(Vector3d pos, String text){
        Text2D label = new Text2D(text, white, 
                "SansSerif", 36, Font.BOLD);
        
        // to turn off culling of back of text
        Appearance app = label.getAppearance();       
        PolygonAttributes pa = app.getPolygonAttributes();
        if (pa == null)
            pa = new PolygonAttributes();
        pa.setCullFace(PolygonAttributes.CULL_NONE);
        if (app.getPolygonAttributes() == null)
            app.setPolygonAttributes(pa);
        
        // to position text
        TransformGroup tg = new TransformGroup();
        Transform3D transform = new Transform3D();
        transform.setTranslation(pos);
        tg.setTransform(transform);
        tg.addChild(label);
        
        return tg;
    }
    
    // create coords. x, z is upper left corner of tile
    // coords added in counter clockwise fashion in order
    // to be in proper order for quad array
    private Point3f[] createCoords(int x, int z) {
        Point3f[] result = new Point3f[4];
        result[0] = new Point3f(x, 0, z + 1);
        result[1] = new Point3f(x + 1, 0, z + 1);
        result[2] = new Point3f(x + 1, 0, z);
        result[3] = new Point3f(x, 0, z);   
        return result;
    }
    
    // as in example from book, KGPJ add a red square in center
    private void addOriginMarker(){
        float q = 0.25f;
        float y = 0.01f;
        ArrayList<Point3f> pts = new ArrayList<Point3f>();
        pts.add(new Point3f(-q, y, q));
        pts.add(new Point3f(-q, y, -q));
        pts.add(new Point3f(q, y, -q));
        pts.add(new Point3f(q, y, q));
        floorBG.addChild(new ColoredTiles(pts, medRed)); 
    }
    
    public BranchGroup getBG(){
        return floorBG;
    }
    
}

class ColoredTiles extends Shape3D {

    private QuadArray plane;


    public ColoredTiles(ArrayList<Point3f> pts, Color3f col){
        plane = new QuadArray(pts.size(), 
            GeometryArray.COORDINATES | GeometryArray.COLOR_3);
        
        Point3f[] quadPoints = new Point3f[pts.size()];
        pts.toArray(quadPoints); // copy elements into array
        
        // 0 is the starting vertex in the QuadArray
        plane.setCoordinates(0, quadPoints); 
        
        // set the color of all vertices. Same for all vertices
        Color3f[] colors = new Color3f[pts.size()];
        Arrays.fill(colors, col);
        plane.setColors(0, colors);
        
        // inherited method from Shape3D
        setGeometry(plane);
        
        setAppearance();
    } 

    private void setAppearance(){
        Appearance ap = new Appearance();
        PolygonAttributes attr = new PolygonAttributes();
        attr.setCullFace(PolygonAttributes.CULL_NONE);
        ap.setPolygonAttributes(attr);

        // inherited methods from Shape3D
        setAppearance(ap);
    }     

  }
