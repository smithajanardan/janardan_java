// CS324E Students: You must fill in the header:

/*
 * File:A1.java
 * 
 * Description: A program to decode a file assumed
 *  to be encrypted with a substitution cipher.
 *  
 * Assignment Number: 1
 * Name: Smitha Janardan
 * EID: ssj398
 * Turnin ID: ssj398
 * 
 * Course Name: CS CS324e
 * 
 * Slip days used this assignment:
 */

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
import javax.swing.JFileChooser;
import javax.swing.UIManager;

//import A1.Pair;

public class A1 {
    
    private static final int NUM_LETTERS = 26;

	private static final Object[][] String = null;
	
	private static TreeMap<Character, Integer> freq;
	
	private static ArrayList<Pair> rank;
	
	private static HashMap<Character, Character> key;
    
    // List of English letters most frequent to least frequent
    private static String  STANDARD_FREQS_STRING = "ETAOINSHRDLCUMWFGYPBVKJXQZ";

    public static void main(String[] args) {
        System.out.println("Pick a file to decrypt.");
        
        String encryptedText = convertFileToString();
        // convert to all upper case
        encryptedText = encryptedText.toUpperCase();
        
        System.out.println("The encrypted text is:");
        System.out.println();
        System.out.println(encryptedText);
        
        LetterInv(encryptedText);
        createKey(rank);
        System.out.println("\nThe current version of the decrypted text is: \n");
        convertText(encryptedText);
        
        Scanner keyboard = new Scanner (System.in);
		while (keepGoing(keyboard) == true) {
			System.out.print("Enter the decrypt character you want to change: ");
			char change = getUpperCaseLetter(keyboard);
			System.out.print("Enter what the character " + change + " should decrypt to instead: ");
			char swtch = getUpperCaseLetter(keyboard);
			changeKey(change, swtch);
			System.out.println("\nThe current version of the key is: ");
			displayKey(key);
			System.out.println("\nThe current version of the decrypted text is: \n");
			convertText(encryptedText);
		}
		
		System.out.println("\nFinal version of key and decrypted text: \nThe final version of the key is: ");
		displayKey(key);
		System.out.println("\nThe final version of the decrypted text is: \n");
		convertText(encryptedText);
        // CS324e Students. Add you code here. Be sure
        // to break solution up into methods.
        // Don't have a giant main method.
    }
 
    public static char getKeyByValue(char value) {
        for (Character keys : key.keySet()) {
            if (value == key.get(keys)) {
                return keys;
            }
        }
		char keys = 0;
		return keys;
    }

    
    private static void changeKey(char change, char swtch) {
		char first = getKeyByValue(change);
		char second = getKeyByValue(swtch);
		key.put(first, swtch);
		key.put(second, change);
	}

	// a method to ask the user if they want to keep going
    // and returns true if they enter 'y' or 'Y'. Otherwise
    // the method returns false.
    public static boolean keepGoing(Scanner keyboard) {
        System.out.println("\nDo you want to make a change to the key?");
        System.out.print("Enter 'Y' or 'y' to make change: ");
        String response = keyboard.nextLine();
        if (response.length() > 0 
            && (response.charAt(0) == 'Y' || response.charAt(0) == 'y')) {
        	return true;
        }
        return false;    
    }
    
    public static void createKey (ArrayList<Pair> list) {
    	key = new HashMap<Character, Character>();
    	for(int i = 0; i < list.size(); i++) {
    		char lett = (list.get(i)).letter;
    		key.put(lett, STANDARD_FREQS_STRING.charAt(i));
    	}
    	System.out.println("\nThe current version of the key is: ");
    	displayKey(key);
    }
    
    public static void LetterInv (String str) {
        freq = new TreeMap<Character, Integer>();
        for(int i = 0; i < str.length(); i++) {
            char letter = Character.toUpperCase(str.charAt(i));
            if(Character.isLetter(letter) == true) {
            	if(freq.containsKey(letter) == false)
                    freq.put(letter, 1);
                else
                    freq.put(letter, freq.get(letter) + 1);
            }
        }
        displayFrequencies(freq);
        rank = new ArrayList<Pair>();
        for(char word : freq.keySet()) {
            rank.add(new Pair(freq.get(word), word));
        }
        Collections.sort(rank);
    }
    
    /*
     * get a letter from user. Keep prompting until 
     * a letter is entered. If letter is lower-case
     * it will be converted to upper case.
     */
    private static char getUpperCaseLetter(Scanner keyboard) {
        String input = keyboard.nextLine();
        // ensure starts with a letter, keep prompting until correct
        while(input == null || input.length() < 1 
                || !Character.isLetter(input.charAt(0))) {
            System.out.println("Sorry . " + input + " doesn't make sense.");
            System.out.print("Please Enter a Letter: ");
            input = keyboard.nextLine();
        }
        return Character.toUpperCase(input.charAt(0));
    }
    
    private static String convertText(String str) {
    	String sortedText = new String();
    	for (int i=0; i < str.length(); i++) {
    		char firstLetter = str.charAt(i);
    		if (Character.isLetter(firstLetter)) {
    			String secondLetter = key.get(firstLetter).toString();
    			sortedText += secondLetter;
    		}
    		else {
    			sortedText += firstLetter;
    		}
    	}
    	System.out.println(sortedText);
    	return str;
    }
    
    
    /**
     * A nested class to make it easier to sort letter, frequency
     * pairs by frequency.
     */
    private static class Pair implements Comparable<Pair> {
        private int freqs;
        private char letter;
        
        private Pair(int f, char le) {
            freqs = f;
            letter = le;
        }
        
        public int compareTo(Pair p) {
            int result = p.freqs - freqs;
            if(result == 0)
                result = letter - p.letter;
            return result;
        }
        
        public String toString() {
            return "[" + freqs + ", " + letter + "]";
        }
    }

    public static void displayKey(HashMap<Character, Character> freqs) {
    	for(char letter : freq.keySet()) {
    		System.out.println("Encrypt character: " + letter + ", Decrypt character: " + freqs.get(letter));
    	}
    }
    
    // a method to show the frequencies of characters
    // in the encrypted text.
    public static void displayFrequencies(TreeMap<Character, Integer> freqs) {
        System.out.println("Frequencies of letters in encrypted file: ");
        System.out.println("Letter - Frequency");
        for(char letter : freqs.keySet())
            System.out.println( letter + " - " + freqs.get(letter));        
    }
    

    /**
     * A method to select a file and convert it to a String.
     * When this method is called a File chooser will open 
     * to allow selection of the file. The file will be read and 
     * converted to a String. Any IO exceptions will result in
     * an empty String being returned.
     * @return A String version of the selected file.
     */
    public static String convertFileToString(){
        StringBuilder sb = new StringBuilder();
        try{
            Scanner sc = new Scanner(pickFile());
            while(sc.hasNextLine()){
                sb.append(sc.nextLine());
                sb.append("\n");
            }
            sc.close();
        }
        catch(IOException e){
            // if any problems occur reset sb.
            // The returned String will now be an empty String
            sb = new StringBuilder();
        }
        return sb.toString();
    }
    
    private static File pickFile(){
        JFileChooser chooser = new JFileChooser(".");
        chooser.setDialogTitle("Pick File to Decrypt:");
        int retval = chooser.showOpenDialog(null);
        File f = null;
        chooser.requestFocusInWindow();
        if (retval == JFileChooser.APPROVE_OPTION)
           f = chooser.getSelectedFile();
        return f;
    }
    
    // stuff to do at start!
    static {
        
        // try to set the look and feel
        try{
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch(Exception e){
            System.out.println("Unable to change look and feel");
        }
        
        // check number of letters correct
        assert STANDARD_FREQS_STRING.length() == NUM_LETTERS;
    }
}
