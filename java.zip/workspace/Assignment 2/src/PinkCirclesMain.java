/*
 * File:A2.java
 * 
 * Description: A program to make pretty circles.
 *  
 * Assignment Number: 2
 * Name: Smitha Janardan
 * EID: ssj398
 * Turnin ID: ssj398
 * 
 * Course Name: CS CS324e
 * 
 * Slip days used this assignment: 0
 */
//imports
import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

//start frame
public class PinkCirclesMain {

	public static void main(String[] args) {
		PinkCirclesFrame f = new PinkCirclesFrame(); 
        f.start();
	}
}

// create frame and put panel in frame
class PinkCirclesFrame extends JFrame {
    private JFrame frame;
    private JPanel panel;
    
    public PinkCirclesFrame() {
        //  set up frame 
        frame = new JFrame();
        frame.setTitle("Color Samples");
        frame.setSize(400, 400);
        frame.setLocation(200, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        panel = new PinkCirclesPanel();
        // panel = new ColorPanel();
        frame.add(panel);
    }

    public void start(){
        frame.setVisible(true);
    }
}

//creates panel
class PinkCirclesPanel extends JPanel{
  private static final int NUM_ROWS = 9;

  // draws the circles in the panel and the background
  public void paintComponent(Graphics g){
      super.paintComponent(g);
      Graphics2D g2 = (Graphics2D)g;
      setBackground(Color.ORANGE);
      double height = (1.0*getHeight())/NUM_ROWS;
      double width = (1.0*getWidth())/NUM_ROWS;
      Ellipse2D.Double ellipse = new Ellipse2D.Double(0, 0, width, height);
      for (double y = 0; y < getHeight(); y += height) {
    	  for (double x = 0; x < width*NUM_ROWS; x += width) {
    		  ellipse.x = x;
    		  ellipse.y = y;
    	      g2.setColor(Color.PINK);
    		  g2.fill(ellipse);
    		  g2.setColor(Color.BLACK);
    		  g2.draw(ellipse);
    	  }
      }
  }
}